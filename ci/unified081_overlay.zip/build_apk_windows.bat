@echo off
setlocal EnableExtensions
chcp 65001 >nul
echo ============================================================================
echo   LocalPilot-Android 0.8.1 + Retro (NES / DOS / SEGA) + Main-Menu Self-Trainer
echo   Проверка 16 моделей (10 Маркет + 6 NES/DOS/SEGA) и 16 классов в DEX
echo ============================================================================
where java >nul 2>nul
if errorlevel 1 (echo [ERROR] JDK 17+ required & exit /b 1)
where python >nul 2>nul
if errorlevel 1 (echo [ERROR] Python 3 required & exit /b 1)
set "JAVA_TOOL_OPTIONS=-Djava.awt.headless=true"
python tools\integrate_adaptive_engine_into_081.py
if errorlevel 1 (echo [STOP] JVM acceptance FAILED & exit /b 1)
if not exist gradlew.bat (echo [ERROR] Gradle wrapper missing & exit /b 1)
call gradlew.bat --no-daemon :app:assembleDebug
if errorlevel 1 (echo [STOP] Gradle build FAILED & exit /b 1)
set "APK=app\build\outputs\apk\debug\app-debug.apk"
if not exist "%APK%" (echo [STOP] APK missing & exit /b 1)
python tools\verify_adaptive_apk.py "%APK%"
if errorlevel 1 (echo [STOP] Missing models or runtime classes. APK NOT RELEASED & exit /b 1)
if defined ANDROID_HOME (
  if exist "%ANDROID_HOME%\build-tools\35.0.0\apksigner.bat" (
    call "%ANDROID_HOME%\build-tools\35.0.0\apksigner.bat" verify --verbose --print-certs "%APK%"
    if errorlevel 1 (echo [STOP] APK signature FAILED & exit /b 1)
  ) else (echo [STOP] apksigner not found: signature must be checked & exit /b 1)
) else (echo [STOP] ANDROID_HOME missing: signature must be checked & exit /b 1)
echo [PASS] APK verified: %CD%\%APK%
if exist "%ANDROID_HOME%\platform-tools\adb.exe" (
  echo [INFO] Для установки на устройство: adb install -r "%APK%"
)
exit /b 0
