@echo off
chcp 65001 >nul
title LocalPilot-Android 0.7.37 — Центр запуска и сборки APK
:menu
cls
echo ============================================================================
echo   LocalPilot-Android v0.7.37 (versionCode 53) — Интеграция с RL Lab
echo   Главный нейродвижок Adaptive Learning Engine + все 10 реальных игр Android
echo ============================================================================
echo.
echo   [1] Проверить и дообучить модели всех 10 игр (Java AdaptiveEngineVerify)
echo   [2] Синхронизировать чекпоинты RL Lab -^> Android (assets/adaptive-engine-v1)
echo   [3] Собрать установочный APK локально (gradlew assembleDebug + ADB install)
echo   [4] Отправить код в GitHub для автосборки APK через GitHub Actions
echo   [5] Выход
echo.
set /p choice="Выберите действие (1-5): "

if "%choice%"=="1" (
    echo.
    java tests/TenGamesVerify.java
    java tests/AdaptiveEngineVerify.java
    pause
    goto menu
)
if "%choice%"=="2" (
    echo.
    python training/sync_rl_lab_to_android.py
    pause
    goto menu
)
if "%choice%"=="3" (
    call build_apk_windows.bat
    goto menu
)
if "%choice%"=="4" (
    call push_to_github_actions.bat
    goto menu
)
if "%choice%"=="5" exit /b 0
goto menu
