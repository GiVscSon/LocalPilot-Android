@echo off
chcp 65001 >nul
echo ============================================================================
echo   LocalPilot-Android 0.7.37 — Отправка в GitHub для автоматической сборки APK
echo ============================================================================
echo.
git status >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    git init
    git remote add origin https://github.com/GiVscSon/LocalPilot-Android.git
)
git checkout -B feat/adaptive-learning-engine-10games-0.7.37
git add -A
git commit -m "Release 0.7.37 (versionCode 53): LocalPilot Adaptive Learning Engine, 10 games support, bundled checkpoints, and tablet pipeline fixes"
git push -u origin feat/adaptive-learning-engine-10games-0.7.37
echo.
echo Готово! Откройте https://github.com/GiVscSon/LocalPilot-Android/actions
echo и скачайте готовый APK из раздела Artifacts после завершения сборки.
pause
