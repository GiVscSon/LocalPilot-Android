#!/usr/bin/env python3
"""
Бесконфликтный хирургический интегратор Adaptive Learning Engine + Retro Console Engine (NES / DOS / SEGA)
+ Main-Menu AutonomousSelfTrainer + BundledModelInstaller в ветку main 0.8.1 (коммит 7d8b528 / 1cc25ff).

Проверяет наличие и SHA-256 всех 16 боевых чекпоинтов (10 игр Маркета + 6 игр NES / DOS / SEGA)
в app/src/main/assets/adaptive-engine-v1/*.zip и прогоняет 5 JVM-комплектов тестирования:
- WeightSpaceSkillsVerify
- TenGamesVerify
- RetroConsoleVerify
- AdaptiveEngineVerify
- Unified081IntegrationVerify
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

WINDOW_FOCUS_ADDITION = """
 public static final class BoundsRebinder {
  public static final long STABLE_REBIND_MS = 160;
  public static final long REBIND_WINDOW_MS = 1200;
  private String expectedOwner = "";
  private int candidateWindow = -1, left, top, right, bottom;
  private long firstSeenMs = -1, lastSeenMs = -1;
  private int stableCount;

  public void reset() {
   expectedOwner = "";
   candidateWindow = -1;
   left = top = right = bottom = 0;
   firstSeenMs = lastSeenMs = -1;
   stableCount = 0;
  }

  public boolean observeCandidate(String owner, int windowId, int l, int t, int r, int b, long nowMs) {
   if (owner == null || owner.isEmpty() || windowId < 0 || r - l < 120 || b - t < 180 || nowMs < 0) {
    reset();
    return false;
   }
   if (!owner.equals(expectedOwner) || windowId != candidateWindow
     || l != left || t != top || r != right || b != bottom
     || firstSeenMs < 0 || nowMs < lastSeenMs || nowMs - firstSeenMs > REBIND_WINDOW_MS) {
    expectedOwner = owner;
    candidateWindow = windowId;
    left = l; top = t; right = r; bottom = b;
    firstSeenMs = lastSeenMs = nowMs;
    stableCount = 1;
    return false;
   }
   lastSeenMs = nowMs;
   if (nowMs - firstSeenMs >= STABLE_REBIND_MS) {
    stableCount++;
    return true;
   }
   return false;
  }

  public int stableCount() { return stableCount; }

  public static int[] remapRoi(int oldWL, int oldWT, int oldWR, int oldWB,
    int newWL, int newWT, int newWR, int newWB,
    int roiL, int roiT, int roiR, int roiB) {
   int oldW = oldWR - oldWL, oldH = oldWB - oldWT;
   int newW = newWR - newWL, newH = newWB - newWT;
   if (oldW < 120 || oldH < 180 || newW < 120 || newH < 180
     || roiL < oldWL || roiT < oldWT || roiR > oldWR || roiB > oldWB
     || roiR - roiL < 60 || roiB - roiT < 60) return null;
   float scaleX = newW / (float) oldW, scaleY = newH / (float) oldH;
   if (Math.abs(scaleX - scaleY) / Math.max(scaleX, scaleY) > 0.08f) return null;
   int nl = newWL + Math.round((roiL - oldWL) * scaleX);
   int nt = newWT + Math.round((roiT - oldWT) * scaleY);
   int nr = newWL + Math.round((roiR - oldWL) * scaleX);
   int nb = newWT + Math.round((roiB - oldWT) * scaleY);
   nl = Math.max(newWL, Math.min(newWR - 1, nl));
   nt = newWT + Math.min(newWB - 1, Math.max(0, nt));
   nr = Math.max(nl + 1, Math.min(newWR, nr));
   nb = Math.max(nt + 1, Math.min(newWB, nb));
   if (nr - nl < 60 || nb - nt < 60) return null;
   return new int[]{nl, nt, nr, nb};
  }
 }

 public record WindowCandidate(int windowId, String packageName, boolean focused, boolean active,
                               int left, int top, int right, int bottom) {
  public boolean nonEmpty() { return right - left >= 120 && bottom - top >= 180; }
 }

 public static int selectApplicationWindow(java.util.List<WindowCandidate> windows,
   boolean explicitBinding, String expectedPackage, int expectedWindowId) {
  if (windows == null || windows.isEmpty()) return -1;
  int focusedId=-1, focusedCount=0, activeId=-1, activeCount=0, onlyId=-1, validCount=0;
  WindowCandidate matched=null;
  for (WindowCandidate w : windows) {
   if (w == null || !w.nonEmpty()) continue;
   validCount++; onlyId=w.windowId();
   if (w.focused()) {focusedCount++; focusedId=w.windowId();}
   if (w.active()) {activeCount++; activeId=w.windowId();}
   if (explicitBinding && expectedPackage != null && expectedPackage.equals(w.packageName())
      && w.windowId() == expectedWindowId) matched=w;
  }
  if (explicitBinding) {
   if (matched == null || expectedWindowId < 0 || expectedPackage == null || expectedPackage.isEmpty()) return -1;
   if (focusedCount > 1 || activeCount > 1) return -1;
   if (focusedCount == 1 && focusedId != expectedWindowId) return -1;
   if (activeCount == 1 && activeId != expectedWindowId) return -1;
   return matched.windowId();
  }
  if (focusedCount > 1) return -1;
  if (focusedCount == 1) return focusedId;
  if (activeCount > 1) return -1;
  if (activeCount == 1) return activeId;
  return validCount == 1 ? onlyId : -1;
 }
}
"""

PANEL_DOCKING_ADDITION = """
 public static final class DockPlan {
  public final Area placement;
  public final boolean microStopMode;
  public final String reason;
  public DockPlan(Area placement, boolean microStopMode, String reason) {
   this.placement = placement;
   this.microStopMode = microStopMode;
   this.reason = reason;
  }
  public boolean usable() { return placement != null; }
 }

 public static DockPlan chooseAdaptive(Area screen, Area compactPanel, Area microStopPanel, Area roi, int marginPx) {
  Area full = choose(screen, compactPanel, roi, marginPx);
  if (full != null) return new DockPlan(full, false, "COMPACT_OUTSIDE_ROI");
  if (microStopPanel != null) {
   Area micro = choose(screen, microStopPanel, roi, Math.max(2, marginPx / 2));
   if (micro != null) return new DockPlan(micro, true, "MICRO_STOP_OUTSIDE_ROI");
  }
  return new DockPlan(null, false, "PANEL_COVERS_ROI");
 }
}
"""

ARCADE_POLICY_ADDITION = """
 public static float paddleDefeatMargin(ArcadeObservation s) {
  if (s == null || s.profile != ArcadeProfile.PADDLE || s.control == null) return 1f;
  float defeatY = s.control.top - 0.03f;
  if (s.obstacles.isEmpty()) return Math.max(0f, defeatY - 0.07f);
  float lowestBottom = 0f;
  for (ArcadeObservation.Box b : s.obstacles) lowestBottom = Math.max(lowestBottom, b.bottom);
  return Math.max(0f, defeatY - lowestBottom);
 }

 public static float urgentBlockTargetX(ArcadeObservation s) {
  if (s == null || s.profile != ArcadeProfile.PADDLE || s.obstacles.isEmpty()) return 0.5f;
  ArcadeObservation.Box best = null;
  for (ArcadeObservation.Box b : s.obstacles) {
   if (best == null || b.bottom > best.bottom + 1e-4f
     || (Math.abs(b.bottom - best.bottom) <= 1e-4f && Math.abs(b.x() - 0.5f) < Math.abs(best.x() - 0.5f))) {
    best = b;
   }
  }
  return best == null ? 0.5f : best.x();
 }
}
"""

MAIN_MENU_SELF_TRAIN_SNIPPET = """  button(box,"Показать панель",()->{PilotService pilot=PilotService.instance;if(pilot==null){toast(CrashDiagnostics.connectionHint(this));return;}pilot.recoverPanel();status.setText(CrashDiagnostics.connectionHint(this));});
  // === ОСНОВНОЕ МЕНЮ: АВТОНОМНОЕ САМООБУЧЕНИЕ И ОБУЧЕНИЕ ДРУГИХ ИГР (NES / DOS / SEGA + 10 ИГР) ===
  try{BundledModelInstaller.install(getFilesDir(),name->getAssets().open(name));}catch(java.io.IOException ignored){}
  AdaptiveLearningEngine.initGlobal(getFilesDir());
  TextView selfTrainHeader=new TextView(this);selfTrainHeader.setText("Самообучение ИИ и ретро-игры (NES · DOS · SEGA · Маркет)");selfTrainHeader.setTextSize(18);box.addView(selfTrainHeader);
  final TextView selfTrainStatus=new TextView(this);selfTrainStatus.setText(AdaptiveLearningEngine.global().selfTrainer().lastMainMenuStatus());box.addView(selfTrainStatus);
  Switch selfLearnSwitch=new Switch(this);selfLearnSwitch.setText("Авто-самообучение (учится сама и обучает другие игры)");
  boolean selfLearnOn=getSharedPreferences(PREF,MODE_PRIVATE).getBoolean("auto_self_learn",true);
  selfLearnSwitch.setChecked(selfLearnOn);AdaptiveLearningEngine.global().selfTrainer().setAutoSelfLearnEnabled(selfLearnOn);
  selfLearnSwitch.setOnCheckedChangeListener((v,on)->{
   getSharedPreferences(PREF,MODE_PRIVATE).edit().putBoolean("auto_self_learn",on).apply();
   AdaptiveLearningEngine.global().selfTrainer().setAutoSelfLearnEnabled(on);
   selfTrainStatus.setText(AdaptiveLearningEngine.global().selfTrainer().lastMainMenuStatus());
   if(on){new Thread(()->{AutonomousSelfTrainer.SelfTrainReport rep=AdaptiveLearningEngine.global().selfTrainer().runFullSelfAndCrossGameCycle(System.currentTimeMillis());runOnUiThread(()->selfTrainStatus.setText(rep.summaryText));},"LocalPilot-AutoSelfTrain").start();}
  });box.addView(selfLearnSwitch);
  button(box,"Самообучение сейчас · NES / DOS / SEGA → Все 16 игр",()->{
   selfTrainStatus.setText("Идёт самообучение (Self-Play + PPO/GAE) и перенос навыков между NES, DOS, SEGA и 10 играми…");
   new Thread(()->{
    AutonomousSelfTrainer.SelfTrainReport rep=AdaptiveLearningEngine.global().selfTrainer().runFullSelfAndCrossGameCycle(System.currentTimeMillis());
    runOnUiThread(()->{selfTrainStatus.setText(rep.summaryText);toast(rep.summaryText);});
   },"LocalPilot-MainMenu-SelfTrain").start();
  });
  LinearLayout retroRow=new LinearLayout(this);retroRow.setOrientation(LinearLayout.HORIZONTAL);box.addView(retroRow);
  for(final RetroPlatform.Console rc:RetroPlatform.Console.values()){
   Button rb=new Button(this);rb.setText("Режим "+rc.id.toUpperCase());
   rb.setOnClickListener(v->{
    AdaptiveLearningEngine.global().selfTrainer().setActiveMainMenuConsole(rc);
    getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("active_retro_console",rc.id).apply();
    selfTrainStatus.setText(AdaptiveLearningEngine.global().selfTrainer().lastMainMenuStatus());
    new Thread(()->{
     AutonomousSelfTrainer.SelfTrainReport rep=AdaptiveLearningEngine.global().selfTrainer().runFullSelfAndCrossGameCycle(System.currentTimeMillis()+rc.ordinal());
     runOnUiThread(()->selfTrainStatus.setText("["+rc.title+"] "+rep.summaryText));
    },"LocalPilot-RetroMode-"+rc.id).start();
   });
   retroRow.addView(rb,new LinearLayout.LayoutParams(0,-2,1));
  }"""


def append_before_last_brace(path: Path, marker: str, snippet: str) -> None:
    if not path.is_file():
        return
    text = path.read_text(encoding="utf-8")
    if marker in text:
        return
    idx = text.rfind("}")
    if idx > 0:
        path.write_text(text[:idx] + snippet, encoding="utf-8")
        print(f"  [INJECTED] {path.relative_to(ROOT)} (+{marker})")


def patch_if_missing(path: Path, marker: str, target: str, replacement: str) -> None:
    if not path.is_file():
        return
    text = path.read_text(encoding="utf-8")
    if marker in text:
        return
    if target in text:
        path.write_text(text.replace(target, replacement, 1), encoding="utf-8")
        print(f"  [PATCHED] {path.relative_to(ROOT)} ({marker})")


def ensure_surgical_patches() -> None:
    append_before_last_brace(
        ROOT / "app/src/main/java/org/localpilot/android/WindowFocus.java",
        "selectApplicationWindow",
        WINDOW_FOCUS_ADDITION,
    )
    append_before_last_brace(
        ROOT / "app/src/main/java/org/localpilot/android/PanelDocking.java",
        "chooseAdaptive",
        PANEL_DOCKING_ADDITION,
    )
    append_before_last_brace(
        ROOT / "app/src/main/java/org/localpilot/android/ArcadePolicy.java",
        "paddleDefeatMargin",
        ARCADE_POLICY_ADDITION,
    )

    ma = ROOT / "app/src/main/java/org/localpilot/android/MainActivity.java"
    patch_if_missing(
        ma,
        "import org.localpilot.android.learning.*;",
        "package org.localpilot.android;",
        "package org.localpilot.android;\nimport org.localpilot.android.learning.*;\nimport org.localpilot.android.retro.*;",
    )
    patch_if_missing(
        ma,
        "Самообучение сейчас · NES / DOS / SEGA → Все 16 игр",
        '  button(box,"Показать панель",()->{PilotService pilot=PilotService.instance;if(pilot==null){toast(CrashDiagnostics.connectionHint(this));return;}pilot.recoverPanel();status.setText(CrashDiagnostics.connectionHint(this));});',
        MAIN_MENU_SELF_TRAIN_SNIPPET,
    )


def main() -> int:
    print("=== Интеграция Adaptive Learning Engine + Retro Console Engine (NES/DOS/SEGA) + Main-Menu Self-Trainer в LocalPilot-Android 0.8.1 ===")
    ensure_surgical_patches()
    subprocess.run([sys.executable, str(ROOT / "training" / "sync_rl_lab_to_android.py")], cwd=ROOT, check=True)
    for verify in [
        "tests/WeightSpaceSkillsVerify.java",
        "tests/TenGamesVerify.java",
        "tests/RetroConsoleVerify.java",
        "tests/AdaptiveEngineVerify.java",
        "tests/Unified081IntegrationVerify.java",
    ]:
        v_path = ROOT / verify
        if v_path.is_file():
            print(f"--- Запуск {verify} ---")
            subprocess.run(["java", str(v_path)], cwd=ROOT, check=True)
    print("=== ВСЕ ПРОВЕРКИ СОВМЕСТИМОСТИ 0.8.1 + 16 МОДЕЛЕЙ (10 МАРКЕТ + 6 NES/DOS/SEGA) + ГЛАВНОЕ МЕНЮ ПРОЙДЕНЫ (PASS) ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
