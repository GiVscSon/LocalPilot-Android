# LocalPilot-Android 0.7.37 (`versionCode 53`) — Техническая документация релиза и архитектуры Adaptive Learning Engine

## 1. Аудит исходного состояния и блокеров (`0.7.34` -> `0.7.37`)

* **Исходный архив**: `LocalPilot_Android_0.7.34_dev_source.zip` (`SHA-256: a30a0b9d479c66aeb285fb5f970e261d633f12b704afe6b539c56d8933aa1b25`).
* **Базовый коммит локального репозитория**: `86b57c3` (ветка `sync/localpilot-android-0734`, соответствующая `0.7.34` / `versionCode 50`, плюс контекст handoff-документа `0.7.36` / `versionCode 52` из Google Drive `1d_U4NLmOQTyzvRQ1PdUVMkLGh0-eH_PCwleFPetbFK8`).
* **Целевая ветка и версия**: `feat/adaptive-learning-engine-10games-0.7.37`, `versionName = "0.7.37"`, `versionCode = 53`.

### Корневые причины реальных планшетных сбоев (по диагностике `Locpiand.zip`)
1. **`TARGET_BOUNDS_CHANGED` как ложная терминальная причина остановки**:
   * В `PilotService.java` любое кратковременное изменение inset-баров или геометрии окна переводило сессию в `STOP`, а при экспорте диагностического архива причина перезаписывалась без разделения между текущим событием и историческим `lastStopReason`.
   * **Исправление**: добавлен `StopContext.java` (разделяющий `USER_STOP_BUTTON`, `PAUSE_FOR_USER`, `RECOVERY_EXHAUSTED`, `BOUNDS_TRANSITION_RECOVERED`, `EXPORT_DIAGNOSTICS_SNAPSHOT` и сохраняющий `historicalLastStop`) и `WindowFocus.BoundsRebinder` (двухкадровый стабилизатор геометрии с окном `160 мс` и пропорциональным пересчётом ROI при искажении соотношения сторон `<= 8%`).
2. **`PANEL_COVERS_ROI` на широкоэкранных и полноэкранных ROI планшета**:
   * В `PanelDocking.java` при невозможности разместить стандартную или компактную панель вне ROI возвращалось `null`, что блокировало запуск.
   * **Исправление**: добавлен `PanelDocking.chooseAdaptive(...)` с fallback-режимом `micro-STOP` (`72dp × 36dp`), размещаемым в безопасном углу без перекрытия активного игрового ROI и с сохранением мгновенной кнопки `STOP`.
3. **`RING_NO_MATCH` / `NO_SAMPLE` / `UNKNOWN` на сетках 6×6 («Нащупай ход») и 7×7 («Мэтч Ворлд»)**:
   * В `GridPuzzleVision.java` метод `ring(...)` возвращал `float[]{Float.NaN, 0, 0}` при контрасте центра и каймы `>= 0.18` и `spread > 0.07`, из-за чего `detect(...)` вызывал `continue` и полностью пропускал 42-мерный дескриптор `describe(...)`. Кроме того, `describe(...)` требовал `40/49` хроматических пикселей в центре на нейтральном фоне.
   * **Исправление**: при `Float.isNaN(ring[0])` сохранён переход к кластеризации 42-мерных патчей `describe(...)` (если токен повторяется на доске), порог хроматических выборок центра на нейтральном фоне снижен с `40/49` до `24/49`, добавлены явные причины `CellReason.HINT_HAND_OCCLUSION` (распознавание белой перчатки-подсказки с тёмным контуром) и `CellReason.SPECIAL_BOOSTER`.
4. **Потеря геометрии поля в «Шипучке» (`BubbleVision`)**:
   * **Исправление**: добавлен `BubbleVision.readRecovering(...)` (однопроходное геометрическое переобнаружение смещённого поля без сброса сессии) и чтение `reserveColor` (вторичного снаряда возле пушки).
5. **Опускающиеся блоки и линия поражения в «Карканоиде» (`ArcadeVision` / `ArcadePolicy`)**:
   * **Исправление**: в `ArcadeVision.paddle(...)` добавлено обнаружение верхних разрушаемых блоков с сортировкой по близости к линии поражения (`-b.bottom`), а в `ArcadePolicy.java` — `paddleDefeatMargin(...)` и `urgentBlockTargetX(...)`, смещающие точку удара ракетки для прицельного сбивания самого низкого блока при безопасном перехвате мяча.

## 2. Архитектура `LocalPilot Adaptive Learning Engine` (`org.localpilot.android.learning.*`)

Движок объединяет аналитическое конструирование весов, обучение по демонстрациям учителя (knowledge distillation), RL-дообучение (PPO+GAE и Double DQN) и строгий защитный шлюз продвижения моделей:

* **`TaskSchema.java` и `ObservationEncoder.java`**: единый 64-мерный формат наблюдений (`OBS_DIM = 64`), маски допустимых действий и провенанс переходов (`SIM`, `SHADOW`, `REAL`) для всех 10 целевых игр.
* **`WeightConstructor.java` и `StudentPolicy.java`**:
  * Аналитическая компиляция проверенных доменных инвариантов в начальные веса компактной нейросети (`64 -> 64 -> 32 -> policy/value` + низкоранговые адаптеры `LoRA rank=4`) до первого градиентного шага.
  * Точечная проекционная коррекция зацикливаний в пространстве весов `repairOscillationSubspace(...)` (в духе *Sparks of Weight-Space Programming*, Takehi et al., MIT CSAIL, Nov 2026: подавление направления циклических действий в скрытом слое без разрушения остальных навыков).
* **`TeacherPolicy.java` и `PpoGaeTrainer.java`**:
  * Учитель на основе правил и краткосрочного поиска формирует целевые распределения и оценки ценности состояний.
  * `PpoGaeTrainer` реализует GAE($\lambda$) с поддержкой переменной длительности жестов ($\gamma^{\Delta t}$) и clipped PPO суррогат, сохраняя совместимость с `DqnTrainer` (Double DQN + Huber loss + target network).
* **`ReplayStore.java` и `ModelCheckpoint.java`**:
  * Строгое разделение буферов `SIM`, `SHADOW` и `REAL`; переходы без `androidAck && visualVerified` отклоняются (`rejectedUnverifiedCount`) и никогда не попадают в `REAL`.
  * Атомарное сохранение чекпоинтов (`ModelCheckpoint`) с проверкой `SHA-256`, версии схемы и `mechanicsVersion` (например, `nashchupay-khod-swap6x6-protected-skulls-v2`).
* **`RealisticCurriculumEnv.java` и `ModelEvaluator.java`**:
  * 4-стадийный куррикулум (`STAGE_1_BASIC_GEOMETRY` -> `STAGE_2_OBSTACLES_AND_SPECIALS` -> `STAGE_3_OCCLUSION_AND_DELAY` -> `STAGE_4_DOMAIN_RANDOMIZATION`) для всех 10 игр.
  * Защитный шлюз `ModelEvaluator.checkPromotionGate`: обновлённая модель (`CANDIDATE_UPDATED`) заменяет активную (`CURRENT_ACTIVE`) только при `safetyViolations == 0` и отсутствии деградации согласия с учителем и средней награды.

## 3. Поддержка всех 10 игр

1. **Шипучка (`SHIPUCHKA`, profile 8)** — `BubbleVision` + `BubblePolicy` + `AdaptiveLearningEngine.chooseBubbleShot`.
2. **Прыгун Ари (`ARI_JUMPER`, profile 1)** — `JumperVision` + `JumperPolicy` + `AdaptiveLearningEngine.chooseJumperAction` (с учётом wrap-around и врагов).
3. **Мэтч Ворлд (`MATCH_WORLD`, profile 9)** — 7×7 `GridPuzzleVision` + `GridPuzzlePolicy` + `AdaptiveLearningEngine.chooseGridMove`.
4. **Карканоид (`KARKANOID`, profile 4)** — `ArcadeVision` (`PADDLE` с верхними блоками) + `ArcadePolicy` + `AdaptiveLearningEngine`.
5. **Маркет Раш (`MARKET_RUSH`, profile 5)** — `ArcadeVision` (`TRAFFIC`) + `ArcadeController` + `AdaptiveLearningEngine`.
6. **Гошан (`GOSHAN_FLAPPY`, profile 6)** — `ArcadeVision` (`FLAPPY`) + `ArcadeController` + `AdaptiveLearningEngine`.
7. **2048 (`GAME_2048`, profile 7)** — `Board2048` + `Verified2048` + `AdaptiveLearningEngine.choose2048Direction`.
8. **Гексон (`HEXON`, profile 12)** — полный адаптер Hexa Sort: `HexaBoard.java`, `HexaVision.java`, `HexaPolicy.java`, `HexaSession.java` + `AdaptiveLearningEngine.chooseHexaMove`.
9. **Нащупай ход (`NASHCHUPAY_KHOD`, profile 11)** — 6×6 обмен соседних клеток с защитой черепов (`special` mask), изолированный под ключом `.protected-skull-swap-v2`.
10. **Котобашня (`KOTOBASHNYA`, profile 13)** — полный адаптер вертикального платформера/башни: `KotobashnyaState.java`, `KotobashnyaVision.java`, `KotobashnyaPolicy.java`, `KotobashnyaFeedback.java` + `AdaptiveLearningEngine.chooseKotobashnyaAction`.
