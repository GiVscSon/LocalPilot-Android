package org.localpilot.android;

import java.io.File;
import java.nio.file.Files;
import java.util.List;
import org.localpilot.android.learning.*;
import org.localpilot.android.retro.*;
import org.localpilot.android.rl.*;

/**
 * Verifies unified integration of LocalPilot 0.8.1 (VisionV2Core, VisionNoveltyMemory,
 * RealGameNeuralCritic, JumperWeightShadow, PaddleTransfer, PaddleWeightLab, WeightSpaceSkills,
 * TextRepetitionGuard, BundledModelInstaller) with the Adaptive Learning Engine, Main-Menu
 * AutonomousSelfTrainer, Main-Menu UnifiedSimulatorHub, and all 16 games (10 Market + 6 NES/DOS/SEGA).
 */
public final class Unified081IntegrationTest {
    private static int assertions = 0;
    private static void check(boolean cond, String msg) {
        assertions++;
        if (!cond) throw new AssertionError(msg);
    }

    public static void main(String[] args) throws Exception {
        File tmpDir = Files.createTempDirectory("lp-unified-081-").toFile();
        AdaptiveLearningEngine engine = AdaptiveLearningEngine.initGlobal(tmpDir);
        check(AdaptiveLearningEngine.global() == engine && tmpDir.equals(engine.storageRoot()),
            "AdaptiveLearningEngine.initGlobal binds global singleton to storageRoot");

        // 1. Verify VisionV2Core & VisionNoveltyMemory integration
        VisionV2Core v2 = engine.visionV2();
        check(v2 != null, "VisionV2Core wired in AdaptiveLearningEngine");
        List<VisionV2Core.Blob> blobs = VisionV2Core.detectMotionBlobs(
            (x, y) -> 0x101010,
            (x, y) -> (x >= 20 && x < 40 && y >= 20 && y < 40) ? 0xf0f0f0 : 0x101010,
            new VisionV2Core.Region(0, 0, 100, 100), 4, 40);
        check(blobs.size() == 1 && blobs.get(0).cells() > 0, "VisionV2Core detects temporal motion blob");

        VisionNoveltyMemory mem = engine.noveltyMemory();
        double nov1 = mem.evaluateNovelty(new float[]{1f, 0f, 0f});
        double nov2 = mem.evaluateNovelty(new float[]{1f, 0f, 0f});
        check(nov1 == 1.0 && nov2 < 1e-6, "VisionNoveltyMemory detects repeated scene trap");

        // 2. Verify RealGameNeuralCritic training on verified outcomes and veto gating
        RealGameNeuralCritic critic = engine.neuralCritic(ArcadeProfile.PADDLE);
        check(critic != null && !critic.isQualifiedForActionVeto(), "Critic starts unqualified for veto");
        float[] goodFeat = RealGameNeuralCritic.extractFeatures(0.5f, 0.86f, 0.5f, 0.5f, 0.1f, 0.3f, 3, 0.9f);
        float[] badFeat = RealGameNeuralCritic.extractFeatures(0.1f, 0.86f, 0.9f, 0.7f, 0.2f, 0.4f, 0, 0.9f);
        for (int i = 0; i < 20; i++) critic.trainStep(goodFeat, true);
        for (int i = 0; i < 16; i++) critic.trainStep(badFeat, false);
        check(critic.isQualifiedForActionVeto(), "Critic qualifies after >=16 pos and >=12 neg verified outcomes");
        String exported = critic.exportStateString();
        RealGameNeuralCritic restored = new RealGameNeuralCritic(ArcadeProfile.PADDLE);
        restored.importStateString(exported);
        check(restored.isQualifiedForActionVeto() && restored.totalUpdates() == 36, "Critic LPN1 state round-trips");

        // 3. Verify PaddleTransfer & PaddleWeightLab bridge
        PaddleTransfer.Candidate cand = PaddleTransfer.trainCandidate();
        check(cand != null && cand.eligible(), "PaddleTransfer candidate passes validation gate: " + cand.report());
        String encoded = PaddleTransfer.encode(cand);
        float decoded = PaddleTransfer.decode(encoded);
        check(Math.abs(decoded - cand.offset()) < 1e-4f, "PaddleTransfer LP-PADDLE-WEIGHTS-v1 round-trip");

        // 4. Verify JumperWeightShadow & TextRepetitionGuard
        JumperWeightShadow shadow = new JumperWeightShadow(new float[]{1f, 2f, 3f});
        JumperWeightShadow updated = shadow.applyDelta(new float[]{0.5f, -0.5f, 0f});
        check(shadow.getWeightsCopy()[0] == 1f && updated.getWeightsCopy()[0] == 1.5f, "JumperWeightShadow immutable");
        TextRepetitionGuard rep = engine.repetitionGuard();
        check(rep.checkAndRecord("TAP_LEFT") && rep.checkAndRecord("TAP_LEFT") && !rep.checkAndRecord("TAP_LEFT"),
            "TextRepetitionGuard blocks 3rd identical action loop");

        // 5. Verify all 16 bundled checkpoints (10 Market + 6 NES/DOS/SEGA) in app/src/main/assets/adaptive-engine-v1/
        check(TaskSchema.GameId.values().length == 16, "Exactly 16 GameIds (10 Market + 6 NES/DOS/SEGA)");
        File assetsRoot = new File("app/src/main/assets");
        AdaptiveLearningEngine prodEngine = new AdaptiveLearningEngine(assetsRoot);
        for (TaskSchema.GameId g : TaskSchema.GameId.values()) {
            TaskSchema schema = TaskSchema.forGame(g);
            File ckpt = prodEngine.checkpointFile(schema);
            check(ckpt.exists() && ckpt.length() > 1000, "Bundled asset checkpoint exists for " + g.id + ": " + ckpt);
            StudentPolicy loaded = ModelCheckpoint.loadRecovering(ckpt, schema);
            check(loaded != null, "Bundled checkpoint SHA-256 verified for " + g.id);
        }

        // 6. Verify API 30 (Android 11) window-binding fix & strict explicit-binding protection
        List<WindowFocus.WindowCandidate> api30UnfocusedActive = List.of(
            new WindowFocus.WindowCandidate(42, "org.localpilot.gamelab", false, true, 0, 0, 1080, 2400)
        );
        check(WindowFocus.selectApplicationWindow(api30UnfocusedActive, false, "", -1) == 42,
            "API 30: unfocused but active single GameLab window is selected for binding");

        List<WindowFocus.WindowCandidate> api30ExplicitAmongTwo = List.of(
            new WindowFocus.WindowCandidate(10, "org.localpilot.android", false, false, 0, 0, 1080, 2400),
            new WindowFocus.WindowCandidate(42, "org.localpilot.gamelab", false, false, 0, 0, 1080, 2400)
        );
        check(WindowFocus.selectApplicationWindow(api30ExplicitAmongTwo, true, "org.localpilot.gamelab", 42) == 42,
            "API 30: explicitly chosen GameLab window binds even before focus bit settles");
        check(WindowFocus.selectApplicationWindow(api30ExplicitAmongTwo, false, "", -1) == -1,
            "API 30: ambiguous unfocused multi-window state without explicit choice fails closed (-1)");
        check(WindowFocus.selectApplicationWindow(api30ExplicitAmongTwo, true, "org.localpilot.gamelab", 99) == -1,
            "API 30: explicit package with wrong windowId (99 != 42) fails closed (-1)");
        check(WindowFocus.selectApplicationWindow(List.of(
            new WindowFocus.WindowCandidate(10, "org.localpilot.android", true, true, 0, 0, 1080, 2400),
            new WindowFocus.WindowCandidate(42, "org.localpilot.gamelab", false, false, 0, 0, 1080, 2400)),
            true, "org.localpilot.gamelab", 42) == -1,
            "Explicit target cannot be replaced by a different focused and active window");
        check(WindowFocus.selectApplicationWindow(api30UnfocusedActive, true, "org.other", 99) == -1,
            "Sole active application is rejected when explicitly selected identity differs");
        check(WindowFocus.selectApplicationWindow(List.of(
            new WindowFocus.WindowCandidate(10, "org.first", false, true, 0, 0, 1080, 2400),
            new WindowFocus.WindowCandidate(42, "org.second", false, true, 0, 0, 1080, 2400)),
            false, "", -1) == -1,
            "Two active windows are ambiguous and reject autonomous binding");

        // 7. Verify BundledModelInstaller copies and verifies all 16 models on first run and preserves user checkpoints
        File freshRoot = Files.createTempDirectory("lp-first-run-models-").toFile();
        BundledModelInstaller.Result initial = BundledModelInstaller.install(freshRoot,
            name -> Files.newInputStream(java.nio.file.Path.of("app/src/main/assets/" + name)));
        check(initial.complete() && initial.installed() == 16,
            "Fresh Android installation loads all 16 preverified bundled model assets: " + initial.report());
        BundledModelInstaller.Result second = BundledModelInstaller.install(freshRoot,
            name -> { throw new java.io.IOException("Assets not needed after installation"); });
        check(second.complete() && second.preserved() == 16 && second.installed() == 0,
            "User model checkpoint files must be preserved across restarts: " + second.report());
        for (TaskSchema.GameId g : TaskSchema.GameId.values()) {
            TaskSchema schema = TaskSchema.forGame(g);
            check(ModelCheckpoint.load(new File(freshRoot, "adaptive-engine-v1/" + g.id + "-" + g.mechanicsVersion + ".zip"), schema) != null,
                "Bundled model checkpoint is usable for " + g.id);
        }
        File missingRoot = Files.createTempDirectory("lp-missing-model-").toFile();
        BundledModelInstaller.Result missing = BundledModelInstaller.install(missingRoot,
            name -> { throw new java.io.IOException("missing asset"); });
        check(!missing.complete() && missing.missing() == 16,
            "A missing bundle cannot be declared fully loaded");

        // 8. Verify Main-Menu UnifiedSimulatorHub (16 simulators render frames, learn themselves, and teach other games)
        UnifiedSimulatorHub simHub = engine.simulatorHub();
        check(simHub != null && simHub.isRunningInMainMenu(), "UnifiedSimulatorHub active by default on Main Menu");
        List<UnifiedSimulatorHub.SimulatorTickResult> simTicks = simHub.runAllSimulatorsCycle(20261106L);
        check(simTicks.size() == 16, "All 16 simulators stepped and trained in Main-Menu UnifiedSimulatorHub");
        check(simHub.totalSimStepsAllGames() == 16 && simHub.totalCrossGameTeachings() >= 10,
            "Simulators learned and taught other games across families: taught=" + simHub.totalCrossGameTeachings());
        for (TaskSchema.GameId g : TaskSchema.GameId.values()) {
            int[] rgb = simHub.renderSimulatorFrameRgb(g, 160, 120);
            check(rgb != null && rgb.length == 160 * 120, "Live RGB frame rendered for simulator " + g.id);
        }

        // 9. Verify Main-Menu AutonomousSelfTrainer & Simulator Hub UI wiring in MainActivity.java
        AutonomousSelfTrainer trainer = engine.selfTrainer();
        check(trainer != null && trainer.isAutoSelfLearnEnabled(), "AutonomousSelfTrainer active by default on Main Menu");
        String mainActivitySrc = Files.readString(java.nio.file.Path.of("app/src/main/java/org/localpilot/android/MainActivity.java"));
        check(mainActivitySrc.contains("Авто-симуляторы в основе (обучаются сами и обучают другие игры)"),
            "MainActivity contains Main-Menu live simulators switch");
        check(mainActivitySrc.contains("mainMenuSimView") && mainActivitySrc.contains("renderSimulatorFrameRgb"),
            "MainActivity embeds live visual simulator View right on the Main Menu");
        check(mainActivitySrc.contains("Авто-самообучение (учится сама и обучает другие игры)"),
            "MainActivity contains Main-Menu self-learning switch");
        check(mainActivitySrc.contains("Самообучение сейчас · NES / DOS / SEGA → Все 16 игр"),
            "MainActivity contains Main-Menu immediate self-training button");
        check(mainActivitySrc.contains("BundledModelInstaller.install(getFilesDir()") && mainActivitySrc.contains("AdaptiveLearningEngine.initGlobal(getFilesDir())"),
            "MainActivity installs all 16 bundled models and binds global engine on startup");

        System.out.println("Unified 0.8.1 + Retro (NES/DOS/SEGA) + Main-Menu Simulators & Self-Trainer integration: " + assertions + " assertions PASS");
    }
}
