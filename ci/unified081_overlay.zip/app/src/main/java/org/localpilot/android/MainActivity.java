package org.localpilot.android;
import org.localpilot.android.learning.*;
import org.localpilot.android.retro.*;
import android.app.*;import android.os.*;import android.content.*;import android.provider.Settings;import android.view.View;import android.widget.*;
public class MainActivity extends Activity {
 public static final String PREF="pilot";
 private TextView status;private TextView selfTrainStatus;private View mainMenuSimView;private Switch automatic;private DiagnosticRequest diagnosticRequest;
 private final Handler simUiHandler=new Handler(Looper.getMainLooper());
 private volatile boolean mainMenuSimLoopActive=false;
 private final java.util.concurrent.atomic.AtomicBoolean simTickInFlight=new java.util.concurrent.atomic.AtomicBoolean(false);
 private static final int REPORT=14;
 private static final class DiagnosticRequest {
  final String session;final android.graphics.Bitmap frame;
  DiagnosticRequest(String session,android.graphics.Bitmap frame){this.session=session;this.frame=frame;}
  void close(){if(frame!=null&&!frame.isRecycled())frame.recycle();}
 }
 private final Runnable simTickRunnable=new Runnable(){
  @Override public void run(){
   if(!mainMenuSimLoopActive)return;
   UnifiedSimulatorHub hub=AdaptiveLearningEngine.global().simulatorHub();
   // No unbounded thread backlog: one training tick at a time, never on UI thread.
   if(hub.isRunningInMainMenu()
      && AdaptiveLearningEngine.global().selfTrainer().isAutoSelfLearnEnabled()
      && simTickInFlight.compareAndSet(false,true)){
    new Thread(()->{
     try{
      UnifiedSimulatorHub.SimulatorTickResult res=hub.stepAndTrainSimulator(null,System.currentTimeMillis());
      runOnUiThread(()->{
       if(mainMenuSimLoopActive && selfTrainStatus!=null)selfTrainStatus.setText(res.statusLine);
       if(mainMenuSimLoopActive && mainMenuSimView!=null)mainMenuSimView.invalidate();
      });
     }catch(RuntimeException failure){
      runOnUiThread(()->{if(mainMenuSimLoopActive&&selfTrainStatus!=null)
       selfTrainStatus.setText("Симулятор приостановлен: "+failure.getClass().getSimpleName());});
     }finally{simTickInFlight.set(false);}
    },"LocalPilot-MainMenu-SimTick").start();
   }
   simUiHandler.postDelayed(this,1200);
  }
 };
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setDecorFitsSystemWindows(false);Object retained=getLastNonConfigurationInstance();if(retained instanceof DiagnosticRequest)diagnosticRequest=(DiagnosticRequest)retained;LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,24,24,24);ScrollView scroll=new ScrollView(this);scroll.addView(box);
  scroll.setOnApplyWindowInsetsListener((view,insets)->{android.graphics.Insets safe=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());if(view.getPaddingLeft()!=safe.left||view.getPaddingTop()!=safe.top||view.getPaddingRight()!=safe.right||view.getPaddingBottom()!=safe.bottom)view.setPadding(safe.left,safe.top,safe.right,safe.bottom);return insets;});setContentView(scroll);scroll.requestApplyInsets();
  TextView title=new TextView(this);title.setText("LocalPilot Android"+(getPackageName().endsWith(".dev")?" Dev":"")+" · "+CrashDiagnostics.buildLabel(this)+"\nАркады и головоломки на телефоне");title.setTextSize(24);box.addView(title);
  TextView help=new TextView(this);help.setText("1. Откройте игру и выберите её профиль: «Игра».\n2. Нажмите «Окно» и выберите приложение с игрой.\n3. Нажмите «Старт» и разрешите показ экрана.\n\nSTOP останавливает игру агента. В первый раз включите управление кнопкой ниже.");box.addView(help);
  button(box,"Включить управление",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
  button(box,"Показать панель",()->{PilotService pilot=PilotService.instance;if(pilot==null){toast(CrashDiagnostics.connectionHint(this));return;}pilot.recoverPanel();status.setText(CrashDiagnostics.connectionHint(this));});
  // === ОСНОВНОЕ МЕНЮ: ВСТРОЕННЫЕ СИМУЛЯТОРЫ 16 ИГР, САМООБУЧЕНИЕ И ОБУЧЕНИЕ ДРУГИХ ИГР (NES / DOS / SEGA + 10 ИГР) ===
  try{BundledModelInstaller.install(getFilesDir(),name->getAssets().open(name));}catch(java.io.IOException ignored){}
  AdaptiveLearningEngine.initGlobal(getFilesDir());
  final UnifiedSimulatorHub simHub=AdaptiveLearningEngine.global().simulatorHub();
  TextView selfTrainHeader=new TextView(this);selfTrainHeader.setText("Симуляторы в основе и самообучение ИИ (NES · DOS · SEGA · 16 игр)");selfTrainHeader.setTextSize(18);box.addView(selfTrainHeader);
  selfTrainStatus=new TextView(this);selfTrainStatus.setText(simHub.lastHubStatus());box.addView(selfTrainStatus);
  // Выпадающий список всех 16 симуляторов + режим авто-ротации прямо в основном меню
  String[] simLabels=new String[TaskSchema.GameId.values().length+1];
  simLabels[0]="Все 16 симуляторов по кругу (обучаются сами и обучают другие игры)";
  int idx=1;for(TaskSchema.GameId g:TaskSchema.GameId.values())simLabels[idx++]="Симулятор: "+g.title+" ("+g.id+")";
  Spinner simSpinner=new Spinner(this);
  simSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,simLabels));
  simSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
   @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){
    if(pos==0){simHub.setAutoRotateAll16(true);}
    else{simHub.setAutoRotateAll16(false);simHub.setFocusedGame(TaskSchema.GameId.values()[pos-1]);}
    selfTrainStatus.setText(simHub.lastHubStatus());
    if(mainMenuSimView!=null)mainMenuSimView.invalidate();
   }
   @Override public void onNothingSelected(AdapterView<?> p){}
  });
  box.addView(simSpinner);
  // Живой экран встроенного симулятора прямо в основном меню
  mainMenuSimView=new View(this){
   private final android.graphics.Paint paint=new android.graphics.Paint();
   @Override protected void onDraw(android.graphics.Canvas canvas){
    super.onDraw(canvas);
    int w=240,h=160;
    int[] rgb=AdaptiveLearningEngine.global().simulatorHub().renderSimulatorFrameRgb(null,w,h);
    android.graphics.Bitmap bmp=android.graphics.Bitmap.createBitmap(rgb,w,h,android.graphics.Bitmap.Config.ARGB_8888);
    android.graphics.Rect dst=new android.graphics.Rect(0,0,getWidth(),getHeight());
    canvas.drawBitmap(bmp,null,dst,paint);
    bmp.recycle();
   }
  };
  int simHeightPx=(int)(190*getResources().getDisplayMetrics().density);
  box.addView(mainMenuSimView,new LinearLayout.LayoutParams(-1,simHeightPx));
  // Переключатели авто-симуляторов и авто-самообучения в основном меню
  Switch simAutoSwitch=new Switch(this);simAutoSwitch.setText("Авто-симуляторы в основе (обучаются сами и обучают другие игры)");
  boolean simAutoOn=getSharedPreferences(PREF,MODE_PRIVATE).getBoolean("auto_main_simulators",true);
  simAutoSwitch.setChecked(simAutoOn);simHub.setRunningInMainMenu(simAutoOn);
  simAutoSwitch.setOnCheckedChangeListener((v,on)->{
   getSharedPreferences(PREF,MODE_PRIVATE).edit().putBoolean("auto_main_simulators",on).apply();
   simHub.setRunningInMainMenu(on);
   selfTrainStatus.setText(simHub.lastHubStatus());
  });box.addView(simAutoSwitch);
  Switch selfLearnSwitch=new Switch(this);selfLearnSwitch.setText("Авто-самообучение (учится сама и обучает другие игры)");
  boolean selfLearnOn=getSharedPreferences(PREF,MODE_PRIVATE).getBoolean("auto_self_learn",true);
  selfLearnSwitch.setChecked(selfLearnOn);AdaptiveLearningEngine.global().selfTrainer().setAutoSelfLearnEnabled(selfLearnOn);
  selfLearnSwitch.setOnCheckedChangeListener((v,on)->{
   getSharedPreferences(PREF,MODE_PRIVATE).edit().putBoolean("auto_self_learn",on).apply();
   AdaptiveLearningEngine.global().selfTrainer().setAutoSelfLearnEnabled(on);
   selfTrainStatus.setText(AdaptiveLearningEngine.global().selfTrainer().lastMainMenuStatus());
   if(on){new Thread(()->{AutonomousSelfTrainer.SelfTrainReport rep=AdaptiveLearningEngine.global().selfTrainer().runFullSelfAndCrossGameCycle(System.currentTimeMillis());runOnUiThread(()->{selfTrainStatus.setText(rep.summaryText);if(mainMenuSimView!=null)mainMenuSimView.invalidate();});},"LocalPilot-AutoSelfTrain").start();}
  });box.addView(selfLearnSwitch);
  button(box,"Шаг симулятора + обучить другие игры сейчас",()->{
   new Thread(()->{
    UnifiedSimulatorHub.SimulatorTickResult tick=simHub.stepAndTrainSimulator(simHub.isAutoRotateAll16()?null:simHub.focusedGame(),System.currentTimeMillis());
    runOnUiThread(()->{selfTrainStatus.setText(tick.statusLine);if(mainMenuSimView!=null)mainMenuSimView.invalidate();});
   },"LocalPilot-MainMenu-SimStep").start();
  });
  button(box,"Самообучение сейчас · NES / DOS / SEGA → Все 16 игр",()->{
   selfTrainStatus.setText("Идёт прогон всех 16 симуляторов (Self-Play + PPO/GAE) и перенос навыков между NES, DOS, SEGA и 10 играми…");
   new Thread(()->{
    simHub.runAllSimulatorsCycle(System.currentTimeMillis());
    AutonomousSelfTrainer.SelfTrainReport rep=AdaptiveLearningEngine.global().selfTrainer().runFullSelfAndCrossGameCycle(System.currentTimeMillis());
    runOnUiThread(()->{selfTrainStatus.setText(rep.summaryText);if(mainMenuSimView!=null)mainMenuSimView.invalidate();toast(rep.summaryText);});
   },"LocalPilot-MainMenu-SelfTrain").start();
  });
  LinearLayout retroRow=new LinearLayout(this);retroRow.setOrientation(LinearLayout.HORIZONTAL);box.addView(retroRow);
  for(final RetroPlatform.Console rc:RetroPlatform.Console.values()){
   Button rb=new Button(this);rb.setText("Режим "+rc.id.toUpperCase());
   rb.setOnClickListener(v->{
    AdaptiveLearningEngine.global().selfTrainer().setActiveMainMenuConsole(rc);
    TaskSchema.GameId focusRetro=rc==RetroPlatform.Console.NES?TaskSchema.GameId.NES_PLATFORMER:(rc==RetroPlatform.Console.DOS?TaskSchema.GameId.DOS_CORRIDOR_ACTION:TaskSchema.GameId.SEGA_HIGH_SPEED_ACT);
    simHub.setAutoRotateAll16(false);simHub.setFocusedGame(focusRetro);
    getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("active_retro_console",rc.id).apply();
    selfTrainStatus.setText(simHub.lastHubStatus());
    if(mainMenuSimView!=null)mainMenuSimView.invalidate();
    new Thread(()->{
     UnifiedSimulatorHub.SimulatorTickResult tick=simHub.stepAndTrainSimulator(focusRetro,System.currentTimeMillis()+rc.ordinal());
     runOnUiThread(()->{selfTrainStatus.setText("["+rc.title+"] "+tick.statusLine);if(mainMenuSimView!=null)mainMenuSimView.invalidate();});
    },"LocalPilot-RetroMode-"+rc.id).start();
   });
   retroRow.addView(rb,new LinearLayout.LayoutParams(0,-2,1));
  }
  TextView panelHelp=new TextView(this);panelHelp.setText("Панель можно свернуть. STOP всегда остаётся доступным.");box.addView(panelHelp);
  button(box,"Обучение по примерам · внешний API",()->startActivity(new Intent(this,WebLearningActivity.class)));
  button(box,"Нейросеть · учебный симулятор",()->startActivity(new Intent(this,TrainingActivity.class)));
  automatic=new Switch(this);automatic.setText("Автоуправление выбранной игрой");automatic.setChecked(getSharedPreferences(PREF,MODE_PRIVATE).getBoolean("auto_control",true));automatic.setOnCheckedChangeListener((v,on)->{getSharedPreferences(PREF,MODE_PRIVATE).edit().putBoolean("auto_control",on).apply();if(PilotService.instance!=null)PilotService.instance.setAutomatic(on);});box.addView(automatic);
  button(box,"Выбрать игру или браузер",()->startActivity(new Intent(this,GamePickerActivity.class)));
  TextView autoHelp=new TextView(this);autoHelp.setText("Для сетки фишек: Игра → Мэтч Ворлд · обмен соседей или Фишки · удалить группу → выберите 6×6, 7×7 либо другой размер → обведите клетки → Старт. Настройки и типы фишек сохраняются. Поддерживаются различимые цветные фишки без специальных эффектов; цели уровня и усилители пока не распознаются. Для аркад другого оформления: Ещё → Настроить распознавание. Для разных игр одного браузера: Игра → Имя игры. STOP всегда останавливает ввод.");box.addView(autoHelp);
  button(box,"Открыть 2048",()->openGame(new Intent(this,Game2048Activity.class),"2048"));
  button(box,"Крестики-нолики",()->openGame(new Intent(this,MiniGamesActivity.class).putExtra("kind",0),"Крестики-нолики"));
  button(box,"Погаси свет",()->openGame(new Intent(this,MiniGamesActivity.class).putExtra("kind",1),"Погаси свет"));
  button(box,"Проверить касания",()->startActivity(new Intent(this,DemoActivity.class)));
  button(box,"Включить сбор примеров",()->{if(PilotService.instance==null){toast("Сначала включите службу");return;}new AlertDialog.Builder(this).setTitle("Сохранять игровые примеры?").setMessage("В памяти приложения останутся только распознанные поля до/после и проверенное действие, без снимков. До 256 примеров / 256 КиБ. Это не обучение. При заполнении сбор выключается, игра продолжается. При ошибке записи управление остановится.").setPositiveButton("Включить",(d,w)->{if(PilotService.instance!=null)PilotService.instance.enableExamples();else toast("Служба отключена");}).setNegativeButton("Отмена",null).show();});
  button(box,"Выключить сбор примеров",()->{if(PilotService.instance!=null)PilotService.instance.disableExamples();});
  button(box,"Экспорт примеров",()->{if(PilotService.instance==null){toast("Сначала включите службу");return;}try{PilotService.instance.exportExamples();startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"localpilot-experience-v1.log"),11);}catch(java.io.IOException e){toast("Хранилище недоступно; исходник сохранён");}});
  button(box,"Восстановить в пустое хранилище",()->{if(PilotService.instance==null){toast("Сначала включите службу");return;}PilotService.instance.disableExamples();new AlertDialog.Builder(this).setTitle("Восстановление примеров").setMessage("Файл будет проверен полностью. Восстановление разрешено только в пустое исправное хранилище. Имеющиеся примеры не заменяются. Импорт не включает обучение или управление.").setPositiveButton("Выбрать файл",(d,w)->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("text/*").addCategory(Intent.CATEGORY_OPENABLE),12)).setNegativeButton("Отмена",null).show();});
  button(box,"Отчёт с кадром игры",this::beginDiagnosticReport);
  button(box,"Экспорт задержек",()->{if(PilotService.instance==null){toast("Сначала включите службу");return;}PilotService.instance.exportMetrics();startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"localpilot-latency.txt"),10);});
  button(box,"Экспорт диагностики сбоя",()->startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"localpilot-crash.txt"),13));
  button(box,"Экспорт журнала",this::beginAuditExport);
  button(box,"STOP и убрать панель",()->{AdaptiveLearningEngine.global().simulatorHub().setRunningInMainMenu(false);if(PilotService.instance!=null)PilotService.instance.hidePanel();});
  status=new TextView(this);box.addView(status);
 }
 private void openGame(Intent intent,String label){startActivity(intent);if(PilotService.instance!=null)PilotService.instance.selectInstalledTarget(getPackageName(),label);}
 @Override public void onResume(){super.onResume();if(automatic!=null)automatic.setChecked(getSharedPreferences(PREF,MODE_PRIVATE).getBoolean("auto_control",true));if(status!=null)status.setText(CrashDiagnostics.connectionHint(this));mainMenuSimLoopActive=true;simUiHandler.removeCallbacks(simTickRunnable);simUiHandler.postDelayed(simTickRunnable,600);}
 @Override protected void onStop(){mainMenuSimLoopActive=false;simUiHandler.removeCallbacks(simTickRunnable);super.onStop();}
 private void beginDiagnosticReport(){
  if(diagnosticRequest!=null)diagnosticRequest.close();
  PilotService pilot=PilotService.instance;android.graphics.Bitmap frame=pilot==null?null:pilot.copyDiagnosticFrame();
  String session=pilot==null?"Accessibility service disconnected; no RAM game snapshot":"";
  if(pilot!=null)session=pilot.exportDiagnosticState();
  diagnosticRequest=new DiagnosticRequest(session,frame);
  try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/zip").addCategory(Intent.CATEGORY_OPENABLE)
    .putExtra(Intent.EXTRA_TITLE,"localpilot-diagnostic.zip"),REPORT);}
  catch(RuntimeException error){diagnosticRequest.close();diagnosticRequest=null;toast("Не удалось открыть сохранение отчёта");}
 }
 private String deviceDiagnostic(){
  StringBuilder out=new StringBuilder("LocalPilot device-v1\n");
  try{android.content.pm.PackageInfo p=getPackageManager().getPackageInfo(getPackageName(),0);out.append("Build=").append(p.versionName).append("/code").append(p.getLongVersionCode()).append(" package=").append(getPackageName());}catch(android.content.pm.PackageManager.NameNotFoundException ignored){}
  out.append("\nmanufacturer=").append(Build.MANUFACTURER).append(" model=").append(Build.MODEL).append(" sdk=").append(Build.VERSION.SDK_INT)
    .append(" android=").append(Build.VERSION.RELEASE).append("\nabis=").append(String.join(",",Build.SUPPORTED_ABIS))
    .append(" cores=").append(Runtime.getRuntime().availableProcessors()).append(" max_heap=").append(Runtime.getRuntime().maxMemory())
    .append(" used_heap=").append(Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())
    .append("\naccessibility_connected=").append(PilotService.instance!=null).append(" automatic=").append(getSharedPreferences(PREF,MODE_PRIVATE).getBoolean("auto_control",true));
  try{ActivityManager manager=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo memory=new ActivityManager.MemoryInfo();manager.getMemoryInfo(memory);
   out.append("\nram_total=").append(memory.totalMem).append(" ram_available=").append(memory.availMem).append(" low_memory=").append(memory.lowMemory).append(" memory_class_mb=").append(manager.getMemoryClass());
  }catch(RuntimeException e){out.append("\nRAM metadata unavailable");}
  return out.append("\nNo serial, account, API key or network identifier is collected.\n").toString();
 }
 private void finishDiagnosticReport(int result,Intent data){
  DiagnosticRequest saved=diagnosticRequest;diagnosticRequest=null;
  if(result!=RESULT_OK||data==null||data.getData()==null){if(saved!=null)saved.close();return;}
  final DiagnosticRequest snapshot=saved==null?new DiagnosticRequest("RAM snapshot unavailable after Activity/process restart",null):saved;
  final android.net.Uri uri=data.getData();final String device=deviceDiagnostic();
  new Thread(()->{
   try{
    byte[] png=null;
    if(snapshot.frame!=null){java.io.ByteArrayOutputStream image=new java.io.ByteArrayOutputStream();if(!snapshot.frame.compress(android.graphics.Bitmap.CompressFormat.PNG,100,image))throw new java.io.IOException();png=image.toByteArray();}
    byte[] report=DiagnosticBundle.create(snapshot.session,device,CrashDiagnostics.report(getApplicationContext()),png);
    try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new java.io.IOException();out.write(report);}
    final boolean included=png!=null;runOnUiThread(()->toast(included?"Отчёт и кадр игры сохранены. Можно прикрепить ZIP к чату":"Отчёт сохранён без кадра: снимка игры в памяти нет"));
   }catch(java.io.IOException|RuntimeException|OutOfMemoryError error){runOnUiThread(()->toast("Отчёт не сохранён полностью. Исходные данные игры сохранены"));}
   finally{snapshot.close();}
  },"LocalPilot-Game-Report").start();
 }
 @Override public Object onRetainNonConfigurationInstance(){return diagnosticRequest;}
 @Override protected void onDestroy(){if(!isChangingConfigurations()&&diagnosticRequest!=null){diagnosticRequest.close();diagnosticRequest=null;}super.onDestroy();}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==REPORT){finishDiagnosticReport(result,data);return;}
  if(request==9){finishAuditExport(result,data);return;}
  if(request==13){
   if(result==RESULT_OK&&data!=null&&data.getData()!=null){
    final android.net.Uri uri=data.getData();
    new Thread(()->{
     try{
      byte[] report=CrashDiagnostics.report(getApplicationContext()).getBytes(java.nio.charset.StandardCharsets.UTF_8);
      try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new java.io.IOException();out.write(report);}
      runOnUiThread(()->toast("Диагностика сбоя сохранена"));
     }catch(java.io.IOException|RuntimeException e){runOnUiThread(()->toast("Не удалось сохранить диагностику сбоя"));}
    },"LocalPilot-Crash-Export").start();
   }return;
  }
  if((request!=10&&request!=11&&request!=12)||result!=RESULT_OK||data==null||data.getData()==null)return;
  try{
   PilotService pilot=PilotService.instance;
   if(pilot==null){toast("Служба отключена: данные RAM недоступны");return;}
   if(request==11){
    byte[] samples=pilot.exportExamples();
    try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new java.io.IOException();out.write(samples);}
    toast("Примеры экспортированы, ввод остановлен");return;
   }
   if(request==12){
    try(java.io.InputStream in=getContentResolver().openInputStream(data.getData())){
     if(in==null)throw new java.io.IOException();int count=pilot.restoreExamples(ExperienceStore.bounded(in));
     toast("Восстановлено примеров: "+count+". Сбор и ввод выключены");
    }return;
   }
   byte[] metrics=pilot.exportMetrics().getBytes(java.nio.charset.StandardCharsets.UTF_8);
   try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new java.io.IOException("Нет файла");out.write(metrics);}
   toast("Замеры экспортированы, ввод остановлен");
  }catch(java.io.IOException|RuntimeException e){toast("Операция не выполнена; исходные данные сохранены");}
 }
 private void beginAuditExport(){
  PilotService pilot=PilotService.instance;if(pilot!=null)pilot.exportDiagnosticState();
  try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/zip").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"localpilot-audit.zip"),9);}
  catch(RuntimeException e){toast("Не удалось открыть сохранение журнала");}
 }
 private void finishAuditExport(int result,Intent data){
  if(result!=RESULT_OK||data==null||data.getData()==null)return;
  final android.net.Uri uri=data.getData();
  new Thread(()->{
   try{
    byte[] bytes=AuditExport.snapshot(getFilesDir());
    try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new java.io.IOException("Нет файла");out.write(bytes);}
    runOnUiThread(()->toast("ZIP журнала сохранён. При отсутствии событий это явно указано внутри"));
   }catch(java.io.IOException|RuntimeException|OutOfMemoryError error){
    runOnUiThread(()->toast("Экспорт не завершён; файл назначения может быть неполным. Исходные журналы сохранены"));
   }
  },"LocalPilot-Audit-Export").start();
 }
 private void button(LinearLayout b,String t,Runnable r){Button x=new Button(this);x.setText(t);x.setOnClickListener(v->r.run());b.addView(x);}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
