# LocalPilot-Android 0.8.1 + Retro (NES / DOS / SEGA) + Автономное самообучение в основном меню

Дата: 2026-11-06
Базовый коммит GitHub `main`: `7d8b528eeb17fd53113ee4fe9079f1e3d43d1407` (`versionCode 53`, `0.8.1-dev-install1081`)

## Что объединено в едином комплекте сборки

1. **Автономное самообучение и кросс-игровой перенос прямо в основном меню (`MainActivity.java` + `AutonomousSelfTrainer.java`)**:
   - Переключатель **«Авто-самообучение (учится сама и обучает другие игры)»** на главном экране (`MainActivity`).
   - Кнопка **«Самообучение сейчас · NES / DOS / SEGA → Все 16 игр»** с живой строкой статуса на главном экране.
   - Быстрые кнопки **«Режим NES»**, **«Режим DOS»**, **«Режим SEGA»** прямо в основном меню.
   - Движок `AutonomousSelfTrainer` сначала самообучает каждую из 16 моделей (`Curriculum Stage 1..3 + Teacher->Student Distillation + PPO/GAE + Online LoRA + ремонт осцилляций`), а затем переносит общие представления (`trunkW1/trunkB1/trunkW2/trunkB2`) между родственными семействами игр (`SkillFamily`: платформеры/прыгуны, коридорные и скоростные экшены, тактические арены и головоломки) строго через промоушен-гейт `ModelEvaluator.checkPromotionGate` (`safetyViolations == 0`).

2. **Подсистема ретро-консолей `org.localpilot.android.retro.*` (NES, DOS, SEGA)**:
   - `RetroPlatform.java`: `NES (8-bit 256×240)`, `DOS (VGA 13h 320×200)`, `SEGA (Mega Drive 16-bit 320×224)` и 6 архетипов (`nes_platformer`, `nes_tactical_arena`, `dos_platform_explorer`, `dos_corridor_action`, `sega_high_speed_act`, `sega_brawler_rungun`).
   - `RetroVision.java`: отделение CRT-экрана от чёрных полос и экранного геймпада, калибровка `VirtualPadLayout`, чтение HUD и маска безопасности 8 действий.
   - `RetroInputBridge.java`: отображение 8 канонических действий (включая аккорды `RIGHT+A`, `DOWN+B` Spin Dash и `B+A`) в жесты через единственный `ActionGate` с проверкой визуального отклика (`Android ACK != успешное игровое действие`).
   - `RetroConsoleEnv.java`: физическая среда и пиксельный рендерер `renderRgbFrame` для всех 6 ретро-архетипов.

3. **Автоустановка всех 16 проверенных моделей при первом запуске (`BundledModelInstaller.java`) и фикс API 30 (`WindowFocus.java`)**:
   - При первом открытии `MainActivity`, `PilotService` или `TrainingActivity` модуль `BundledModelInstaller.install(getFilesDir(), getAssets()::open)` копирует и проверяет по `SHA256SUMS` и `TaskSchema` все **16** моделей (`10` игр Маркета + `6` профилей NES/DOS/SEGA) из `assets/adaptive-engine-v1/*.zip` во внутреннее хранилище `getFilesDir()/adaptive-engine-v1/`, не затирая пользовательский опыт.
   - `AdaptiveLearningEngine.initGlobal(getFilesDir())` связывает глобальный движок с `getFilesDir()`, чтобы обучение из основного меню (`MainActivity`) и служба управления (`PilotService`) работали с одними и теми же боевыми чекпоинтами.
   - В `WindowFocus.selectApplicationWindow` и `PilotService.awaitChosenWindow` сохранены строгий запрет подмены явно выбранного окна другим активным приложением и двухкадровая стабилизация инсетов Android 11 (API 30) через `BoundsRebinder`.

4. **Результаты проверок в JVM 17**:
   - `sync_rl_lab_to_android.py`: `16/16` моделей (`SHA-256` `weights.bin` + `manifest.json` + `game_id` `OK`).
   - `WeightSpaceSkillsVerify`: `8 assertions PASS`.
   - `TenGamesVerify`: `34 assertions PASS`.
   - `RetroConsoleVerify`: `91 assertions PASS` (включая цикл основного меню `16/16` самообученных игр и `13` принятых межвидовых переносов навыков).
   - `AdaptiveEngineVerify`: `138 assertions PASS`.
   - `Unified081IntegrationVerify`: `74 assertions PASS`.
   - Итого: **345 утверждений PASS**.

5. **Статус физической приёмки**:
   - В изолированной облачной среде без подключённого телефона и локального Android SDK финальная компиляция `classes*.dex` и подпись `apksigner` выполняются через автономный 4-ячеечный блокнот Google Colab (`LocalPilot_Android_0.8.1_Retro_NES_DOS_SEGA_APK_Builder.ipynb`) с обязательным гейтом `tools/verify_adaptive_apk.py` (`16` моделей + `16` классов в DEX).
   - Приёмка на физическом Android-устройстве (`DEVICE_NOT_VERIFIED` до прогона на телефоне) остаётся обязательным шагом после установки собранного APK.


## Коррекция сборки 7 ноября 2026

- Вызовы симуляторов теперь сохраняют опыт строго с `TaskSchema.Provenance.SIM`; нельзя выдавать симуляцию за реальный Android ACK.
- `MainActivity` не накапливает параллельные фоновые потоки при длительных шагах обучения; авто-обучение регулируется обоими переключателями.
- NES/DOS/SEGA представлены физическими учебными средами, а не эмуляторами исполняемых игровых ROM.
- Android APK и физическая приёмка отдельно требуют успешного запуска исправленного Colab-блокнота.
